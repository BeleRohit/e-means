# Experiment log

All user-facing dates use Asia/Kolkata. Machine-readable manifests use UTC timestamps. Recorded results are evidence from actual executions, not predictions.

## 11 November 2026 — Phase 1 numerical validation

Environment: Python 3.13.7, NumPy 2.5.4, pytest 9.2.0, optional faiss-cpu 1.16.0; macOS ARM64. See the run manifest for exact platform/Python strings. Paper parsing packages were installed as development tools; they are not package runtime dependencies.

Commands:

```bash
.venv/bin/python -m pip install -e '.[test]'
EMEANS_REFERENCE_DIR=/tmp/emeans-reference-2b648f .venv/bin/python -m pytest -q
```

Outcome: **54 passed**. Six executed optional cases compare against authors' source at `2b648f0605f2ef3d14c4705350f8a0b214463878`, verified by SHA256 before import. The remaining 48 tests independently cover distance/stats arithmetic, scalar full-loop oracle, Lloyd descent, reproducibility, validation, split weighting/geometry/cadence, finalization, two precisions, degenerate data, and actual experiment subprocess/artifact behavior. Normal offline tests explicitly skip the six reference cases if no reference source is supplied.

Additional checks: all walkthrough notebook code cells executed successfully; the installed package ran from outside the repository without importing Faiss or PyTorch. The offline test variant completed with **48 passed, 6 skipped**. All 12 result JSON/NPZ records, shared per-pair data hashes, and the manifest's source digest were verified against the final implementation. Source digest: `5272b26ac263aa5b2964389861ff8aad26f1beab519d6f8a85b6ac8610e65d83`.

Findings: paper and modern reference use different initialization, split delta, fitted coefficients, low-dimensional defaults, and tail policies. Tests align relevant values rather than assert equivalence between different recipes. Eq. 5's t/M schedule does not reach the floor on its final executed update. Closing means minimize fixed-code SSE; they should not be tested against an unsupported monotonicity claim for freshly evaluated final EMA centers.

## 11 November 2026 — paired synthetic CPU smoke experiment

Command:

```bash
.venv/bin/python scripts/benchmark.py --config configs/phase1_smoke.json --output results/phase1_smoke_2026-11-11
```

Status: **complete, 12 runs**. [Manifest and environment](results/phase1_smoke_2026-11-11/manifest.json). Each pair shares exact train/test matrices and initialization; artifacts contain hashes and centers/labels. Each solver uses a fresh process. Config: seeds 0,1,2; n_train=1200, n_test=400, d=16, k=8; Lloyd up to 25 iterations with exact stopping; e-means 3 epochs, B=64, alpha0=.2, keep tails, paper revival/default finalizer; FP64. The experiment deliberately supplies B/alpha, rather than representing the fitted large-data laws as optimal for these tiny mixtures.

Medians across three seeds; MSE is mean squared norm per vector. Timing is single-run local measurement, not a statistically established speedup.

| Dataset | Algorithm | Final train MSE | Final test MSE | Solver loop (ms) | Entire fit (ms) | Peak process RSS (MiB) |
|---|---|---:|---:|---:|---:|---:|
| Separated mixture | Lloyd | 42.235696 | 44.246065 | 7.576 | 16.908 | 36.344 |
| Separated mixture | e-means | 54.698006 | 52.518848 | 6.774 | 11.044 | 36.578 |
| Overlapping mixture | Lloyd | 14.909558 | 15.397616 | 20.559 | 43.052 | 36.328 |
| Overlapping mixture | e-means | 15.225443 | 15.609053 | 6.959 | 11.211 | 36.594 |

Interpretation: at these explicit budgets, e-means' median runtime is lower and its median MSE is higher on both mixtures. This does not reproduce the paper's speed/quality claim. Random row initialization can leave some true mixture modes unrepresented; neither method is guaranteed to find the global solution. Additional epochs, hyperparameter experiments and realistic embedding data belong to later evaluation.

Measurement limits: loop time excludes fixed-center epoch evaluation and initialization; total fit includes them. E-means closing time is recorded separately. RSS is whole-process `ru_maxrss` in bytes, including Python/NumPy imports, data and evaluation; it cannot establish a meaningful algorithm-only memory advantage at this scale. Timings are short, unrepeated and susceptible to scheduler/background contention. No confidence interval or hardware-normalized conclusion is supported. The complete per-epoch curves are retained in each JSON `history` rather than collapsed into the median table.

## Phase 1 follow-up plan (historical)

The original follow-up plan was automatic-law sweeps, held-out real embeddings, repeated timings, matched-MSE comparisons, slow-EMA train/test tradeoffs, and PyTorch parity before CUDA work. Some items are completed by Phase 2 below; realistic embedding-scale and CUDA measurements remain future work.

## 11 November 2026 — Phase 2 CPU correctness and regression gate

Environment: Python 3.13.7, NumPy 2.5.4, PyTorch 2.15.0, pytest 9.2.0, faiss-cpu 1.16.0, matplotlib 3.11.2; macOS ARM64. Exact versions/platform are retained in [phase2_validation_environment.json](docs/phase2_validation_environment.json).

Command:

```bash
EMEANS_REFERENCE_DIR=/tmp/emeans-reference-2b648f .venv/bin/python -m pytest -q
```

Outcome: **101 passed, 4 skipped**. All original 54 cases pass, plus historical centers/labels from all twelve Phase 1 runs match. Four FP32/FP64 CUDA Lloyd/e-means cases skip because `torch.cuda.is_available()` is false. CPU checks include per-update sum/count parity, exact controlled donor IDs, full histories/moving codes, all finalizers, half-life/speed conversion, independent scalar slow-EMA recurrence, validation, no-grad/input ownership and actual research subprocess execution.

Seven optional cases execute against pinned authors' code, including a new slow recurrence/split **primitive** comparison. No released end-to-end authors' slow finalizer was found in the audited files, so its missing policy oracle is an explicit limit. The full suite initially exposed a bundled Faiss/PyTorch OpenMP conflict on macOS; isolating reference cases in subprocesses resolved it without an unsafe duplicate-runtime override. Paper/reference differences documented in Phase 1 remain in force.

FP64 CPU parity assertions use atol/rtol=2e-12; FP32 uses 2e-5 over multi-epoch trajectories. These are tested tolerances for controlled inputs, not a guarantee of identical assignments near every distance tie or on every device/version.

Additional verification: the offline variant completed with **94 passed, 11 skipped** (seven optional authors' cases plus four CUDA cases). Editable installation with all Phase 2 extras succeeded. The public lazy PyTorch API ran from outside the repository; base `import e_means` imported neither Torch nor Faiss. All Phase 1/2 notebook code cells executed successfully, and exported convergence plots were visually inspected. Final source digest still matches all 120 measured records and the manifest.

## 11 November 2026 — Phase 2 public-data CPU experiment

Commands:

```bash
.venv/bin/python scripts/fetch_cpu_data.py --output data
.venv/bin/python scripts/research_cpu.py --config configs/phase2_cpu.json --output results/phase2_cpu_2026-11-11
MPLCONFIGDIR=.mplconfig .venv/bin/python scripts/summarize_cpu.py results/phase2_cpu_2026-11-11
```

The executed data preparation used the same verified archives through `--archive-dir /tmp`; the command above downloads those pinned archives when no local cache is supplied.

Status: **complete, 120 measured fits, all verified**. [Manifest](results/phase2_cpu_2026-11-11/manifest.json), [full summary and convergence statistics](results/phase2_cpu_2026-11-11/summary.json), [PNG curves](results/phase2_cpu_2026-11-11/convergence.png), [SVG curves](results/phase2_cpu_2026-11-11/convergence.svg). The directory also retains 120 JSON/NPZ pairs, config.json, and a checksummed source.zip snapshot. Source digest: `4fed06289da4ffbafd68e0e639dee39f2aab55754f10893d66727fce256a1b3d`.

Datasets: UCI optical digits (3823 train / 1797 test, 64 features) and pen digits (7494 / 3498, 16 features), original provided splits. Labels are discarded. Feature ranges are scaled by fixed published constants 16 and 100, respectively. Archive/member/array hashes and attributions are in [data/README.md](data/README.md) and `data/*.json`; no test-based fitting or selection occurs.

Predeclared settings: k=32, FP64, shared initialization per dataset/seed, seeds 0–4, two repeated fresh-process fits per seed, one-thread settings, Lloyd up to 25 iterations with exact stopping, e-means 5 epochs at B=128 and alpha0=.2, retained tails and paper revival parameters. Slow EMA uses factor .25 of the theoretical cosine floor (.005 constant step); it is fixed a priori, not selected using test results. Both backends use the same controlled seed streams. These are explicit development configurations, not automatic-law experiments.

Each row below reports **mean ± sample SD across five seed means**. Repeated fits are averaged within each seed first; this avoids treating ten repetitions as ten independent seeds. MSE is recomputed in FP64 against returned centers. Runtime is entire fit in milliseconds; RSS is whole-process high-water MiB through fit, including framework imports and dataset memory.

| Dataset | Backend / finalizer | Train MSE | Test MSE | Fit ms | Peak process MiB |
|---|---|---:|---:|---:|---:|
| Optical | NumPy Lloyd | 1.836249 ± .004449 | 2.072305 ± .010209 | 1336.38 ± 52.26 | 45.68 ± .05 |
| Optical | NumPy e-means closing | 1.824642 ± .012599 | 2.034950 ± .020987 | 324.84 ± .52 | 46.04 ± .08 |
| Optical | NumPy e-means slow | 1.830756 ± .012879 | 2.037737 ± .019625 | 339.68 ± 14.79 | 46.18 ± .16 |
| Optical | PyTorch Lloyd | 1.836249 ± .004449 | 2.072305 ± .010209 | 1553.57 ± 90.72 | 206.66 ± 3.63 |
| Optical | PyTorch e-means closing | 1.824642 ± .012599 | 2.034950 ± .020987 | 433.01 ± 5.65 | 209.90 ± .59 |
| Optical | PyTorch e-means slow | 1.830756 ± .012879 | 2.037737 ± .019625 | 447.13 ± 5.67 | 209.92 ± .11 |
| Pen | NumPy Lloyd | .254665 ± .004793 | .272405 ± .004186 | 689.09 ± .40 | 42.55 ± .11 |
| Pen | NumPy e-means closing | .249024 ± .002097 | .265048 ± .007126 | 175.46 ± .37 | 42.67 ± .12 |
| Pen | NumPy e-means slow | .251278 ± .002191 | .265268 ± .006571 | 182.33 ± 2.01 | 42.62 ± .09 |
| Pen | PyTorch Lloyd | .254665 ± .004793 | .272405 ± .004186 | 814.09 ± 20.72 | 206.41 ± .35 |
| Pen | PyTorch e-means closing | .249024 ± .002097 | .265048 ± .007126 | 260.03 ± .79 | 206.49 ± .72 |
| Pen | PyTorch e-means slow | .251278 ± .002191 | .265268 ± .006571 | 311.59 ± 49.83 | 207.12 ± .27 |

Findings: all **60 NumPy/PyTorch paired FP64 center arrays and final label arrays were identical** in these runs (maximum absolute center difference 0). Repeated artifacts within each seed were also identical. Under these explicit budgets, e-means closing has lower mean train/test MSE and fit time than Lloyd at its iteration cap on both datasets. Slow EMA at factor .25 has slightly higher mean test MSE than closing on both; this setting does not reproduce a generalization improvement here. The unoptimized PyTorch CPU implementation is slower and has higher whole-process RSS than NumPy on these small problems.

Interpretation limits: observations are limited to two small real feature datasets, five seeds, two timings per seed, one macOS CPU environment and explicit B/alpha. They are not the paper's high-dimensional embedding workloads, matched-MSE time-to-target trials, automatic scaling-law validation, statistical confidence intervals or GPU results. Main-state convergence lines precede finalization; endpoint markers are final readouts. The slow and closing variants share the same main trajectory. RSS largely includes PyTorch runtime overhead and cannot establish an isolated algorithm memory cost. No CUDA, RunPod, Triton or distributed experiment ran.

Recommended next measurement gate: actual CUDA correctness with FP32/FP64 and slow revival, synchronized/event timings plus allocator peaks, then pinned realistic embeddings at the fitted scale with predeclared matched-MSE targets. GPU optimization follows measured baseline correctness.

## 11 November 2026 — Phase 3 local preparation, not GPU results

Status: **local preparation complete; zero GPU measurements; NVIDIA gate closed**. Host remains macOS ARM64, Torch 2.15.0, `torch.version.cuda=None`, `torch.cuda.is_available()=False`. No Pod was provisioned and no GPU calibration, warmup or contender ran.

```bash
EMEANS_REFERENCE_DIR=/tmp/emeans-reference-2b648f .venv/bin/python -m pytest -q
bash -n runpod/bootstrap.sh runpod/run.sh
```

Outcome: **146 passed, 32 skipped**. The original 101 passing Phase 2 cases remain passing. New coverage is 28 CPU rehearsals of the NVIDIA matrix and 17 protocol/config/data/timing-order checks. The 28 new NVIDIA cases and four original CUDA cases skip explicitly. Timer mocks check ordering/units/peak-reset semantics, not actual CUDA behavior, and do not save GPU verification certificates. Numeric clustering algorithms are unchanged.

Primitive tolerances are FP32 atol/rtol=3e-6 and FP64=2e-12; full-trajectory CUDA budgets are 1e-4 and 1e-10, with exact controlled assignments/donor identities still required. These remain prepared assertions, not GPU-validated tolerances. NVIDIA failures must be investigated before benchmarks proceed; tolerances are not automatically widened.

Real data: ANN-Benchmarks GloVe-100 HDF5 layout was inspected with h5py 3.16.0. A slow full download was interrupted after obtaining the needed training prefix. Only selected raw ranges and their prepared arrays are SHA256 verified: 16,384 original train and 2,048 original test vectors, 100 dimensions, no renormalization/fitted preprocessing. The test range returned exact HTTP 206/Content-Range and the recorded ETag. The entire 485,413,888-byte parent file is **not** SHA256-verified. Pins, layout and credit are in [data/glove100_source.json](data/glove100_source.json); prepared array hash is `a85b3b6fa7a7616130acc82d3a4ab7709bd086765d4df91f7970093875f1e404`. Squared Euclidean clustering results are not ANN angular retrieval metrics.

Executed commands:

```bash
.venv/bin/python scripts/fetch_gpu_embeddings.py --cache-dir /tmp
.venv/bin/python scripts/benchmark_cuda.py --config configs/gpu_smoke.json --output results/phase3_preparation_2026-11-11/release_smoke --prepare-only
.venv/bin/python scripts/benchmark_cuda.py --config configs/gpu_research.json --output results/phase3_preparation_2026-11-11/release_research --prepare-only
.venv/bin/python scripts/validate_cuda.py --output results/phase3_preparation_2026-11-11/release_gate
```

The release preparation manifests cover four smoke and eighteen research workload/seed/dtype combinations, with empty run lists and `gpu_verified: false`. Source/config/script/regression-fixture fingerprint: `04cc5d83d51c18581423449ef7008d9ecaa5fcc5e12c9aa032f303b7105bfea8`. Earlier non-release folders retain intermediate preparation-only snapshots. The hardware gate exits **2**, writes `hardware_unavailable`, and never executes pytest or issues a successful CUDA report. This is an expected closed gate, not a failed numerical GPU experiment.

The harness requires a complete, zero-skip NVIDIA suite, source/environment/device matching and checksummed XML. Prepared measurements separate target calibration, warmups, rotated repeats, synchronized/event timing, allocator peaks/baselines, MSE, throughput and per-epoch observations. Monitored main-state target hits and returned-finalizer target hits are distinct; misses remain censored. Summaries average repeats within seed before calculating sample SD, and preserve conditional target-hit counts. See [docs/RUNPOD.md](docs/RUNPOD.md) for all definitions and exact commands.

The official image tag `pytorch/pytorch:2.5.1-cuda12.4-cudnn9-runtime` resolved through Docker registry metadata to `sha256:c8268a92a69bd500f8be0e665b2630ee006dadaf7bfbc24249141b15ff622755`. The Linux AMD64/Python 3.11 image and exact dependency overlay are **not container/GPU validated locally**. Bootstrap and the complete numerical suite must run on the eventual host. Shell syntax and local protocol tests passed. No Triton optimization, torch.compile, ANN assignment or distributed clustering was introduced.

## 11 November 2026 — requested Runpod agent setup

Fetched and followed [the official guide](https://agents.runpod.io/), using its Codex route:

```text
codex plugin marketplace add https://github.com/runpod/runpod-plugins-official.git
codex plugin add runpod@runpod
```

Verified with Codex CLI 0.160.0: `runpod@runpod` **installed, enabled**, version **2.0.0**; 17 nonempty skill files; hosted MCP endpoint `https://mcp.runpod.io/` configured through the plugin. No duplicate server, API key, separate CLI or Flash SDK was added. User-level plugin settings were changed as requested; no credentials were printed or copied into the repository.

Authentication/account access is **unverified**. The remaining guide step is to fully quit/reopen Codex Desktop, approve OAuth when prompted, then verify by listing Pods. This session did not list Pods or provision resources. Plugin installation is not evidence of authenticated account connectivity or CUDA access.

## 11 November 2026 — requested GPU execution: stopped at access gate

Reviewed checkout `c1b104b` (clean tracked working tree), CUDA tests, pinned image/dependencies, both GPU configurations, `validate_cuda.py`, and the Runpod bootstrap/orchestration scripts. Requested infrastructure is one RTX 4090 (24 GB), with a total budget below $10 including storage, subject to explicit paid-provisioning approval.

Read-only connection checks: Runpod plugin remains enabled and configured for `https://mcp.runpod.io/`, but this session exposes no Runpod MCP tools. `runpodctl` is absent and `RUNPOD_API_KEY` is not set. No credential values were read or printed. Account authentication, balance, active Pods, GPU stock and current pricing could not be verified. No resources were created/modified, no dependencies were installed remotely, and no CUDA tests or GPU benchmarks ran. This is an access-blocked attempt, not an experimental failure or measured GPU result.

The existing `runpod/run.sh` enforces the numerical gate and exports results, but does not enforce a dollar cap or terminate the cloud Pod. Before paid execution, establish a conservative current-rate budget including storage, an external deadline/cleanup mechanism, artifact retrieval and verified Pod termination. The user's $10 ceiling is not treated as explicit permission to provision.

Next action: fully quit/reopen Codex Desktop, approve Runpod OAuth when prompted, then verify the connection by listing Pods/account balance. After read-only access succeeds, obtain a live RTX 4090/storage quote and request explicit approval for that concrete spending/teardown plan. Existing preparation and all prior artifacts are preserved.

## 11 November 2026 — CLI authentication verified; provisioning not authorized

`runpodctl 3.1.0-5ab53b9` account read succeeded with network access enabled: balance $10, current spend $0/hour. `runpodctl pod list --all` returned an empty list. MCP tools remain absent; authenticated CLI access is available. These observations supersede the earlier access-blocked audit. No credential values are recorded here.

The live GPU catalog including unavailable entries reports RTX 4090 (24 GB) unavailable, with listed Secure $0.89/hour and Community $0.34/hour GPU rates. A40 (48 GB) reports available, Secure $0.59/hour, low stock in CA-MTL-1 and EU-SE-1. These are catalog GPU rates, not complete storage-inclusive quotes or reservations.

Re-reviewed pinned image/bootstrap, smoke/research configs and execution orchestration. Stop at the user's explicit provisioning-approval gate: no resources created, CUDA tests executed, or GPU measurements obtained. GPU selection, storage pricing, budget deadline and verified teardown still require resolution before execution.
