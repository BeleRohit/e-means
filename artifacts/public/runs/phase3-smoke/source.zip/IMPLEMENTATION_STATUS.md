# Implementation status

Updated: 11 November 2026 (Asia/Kolkata).

## Phase 1 — implemented and locally verified

- [x] Package with NumPy-only runtime dependency, editable installation verified.
- [x] Lloyd full-batch assignment/means, deterministic initialization, empty-cluster policy, convergence history and stopping.
- [x] Explicit sum/count e-means EMA, tiny initial mass, literal cosine equation, and separate stochastic/fixed-center losses.
- [x] Every-five-update dead-cluster checks, weighted live donors without replacement, alternating split perturbations, count/sum consistency.
- [x] Published scaling-law coefficients and explicit batch/step overrides.
- [x] Last-epoch moving-assignment means; preserve empty centers; fresh final labels kept separately.
- [x] Float64 baseline and float32 option; bounded assignment tiles; finite-input/shape/config checks.
- [x] 48 independent numerical/API/experiment tests plus six pinned authors' comparisons: **54 passed** locally.
- [x] Paired synthetic convergence, train/test MSE, runtime and process RSS experiment: two datasets × three seeds × two algorithms, **12 runs**.
- [x] Source/config/data hashes, immutable run directories, serialized configurations, environment metadata, JSON histories and NPZ artifacts.
- [x] PAPER_MAPPING.md, REPRODUCTION_NOTES.md, EXPERIMENT_LOG.md and runnable walkthrough.

The Phase 1 correctness gate is satisfied for the tested cases. This does not establish large-scale performance, optimal scaling-law behavior on tiny data, or general parity for different random streams. Local validation used Python 3.13 on macOS ARM64; the full supported Python/NumPy version matrix remains unverified.

## Phase 2 — implementation and CPU correctness verified

- [x] Independent PyTorch Lloyd/e-means with shared configuration/API semantics and optional CPU/CUDA device selection.
- [x] FP32/FP64 tensor arithmetic, two-dimensional chunked direct-distance assignment, detached inputs and tensor outputs.
- [x] Matched NumPy initialization/order/donor RNG streams; tests compare every update, actual revival identities, whole trajectories and final readouts.
- [x] Slow count/sum EMA on both backends, independent constant-speed scalar oracle, optional explicitly defined half-life, and mirrored main-model splits.
- [x] Slow recurrence/split arithmetic compared with pinned authors' primitives; missing complete authors' slow finalizer is documented.
- [x] Historical twelve-run NumPy result regression checks; original 54 tests preserved.
- [x] Complete suite: **101 passed, 4 CUDA cases skipped** on this CPU-only macOS ARM64 environment.
- [x] Optional Faiss reference cases isolated in subprocesses to avoid conflicting bundled OpenMP runtimes.
- [x] Pinned public UCI optical/pen digits acquisition, original splits, no labels in training, fixed feature-range scaling.
- [x] Research runner with five seeds, two repetitions, six methods, source/config snapshots, checksummed artifacts and explicit timing/RSS definitions.
- [x] Coverage/integrity verification, per-seed aggregation before mean/sample-SD calculation, and exportable train/test convergence plots.

- [x] Real-data experiment completed: **120 fits**, two datasets × six methods × five seeds × two repetitions, with verified coverage/integrity and deterministic repeated arrays.
- [x] All 60 paired NumPy/PyTorch FP64 center/label outputs identical in those runs; measured mean/sample-SD results and convergence curves retained.

Actual research-run outcomes are recorded in EXPERIMENT_LOG.md. No CUDA measurements or RunPod tasks have been performed. FP32/FP64 parity is established for the controlled CPU cases, not universally for arbitrarily close assignment ties or every software/hardware version.

## Phase 3 — local preparation complete; NVIDIA execution gate closed

- [x] New correctness matrix: 28 CPU rehearsal cases and 28 matching guarded NVIDIA cases, covering FP32/FP64 assignment/statistics, literal cosine updates, revival/own-state shadow splits, finalizers, full Lloyd/e-means trajectories, tails, empty clusters and no-grad behavior.
- [x] NumPy plus PyTorch CPU references; predeclared primitive and trajectory tolerances, with exact controlled labels/donor identities. Existing four CUDA cases retained.
- [x] Full suite locally: **146 passed, 32 skipped**. All 32 skips require NVIDIA CUDA. Original Phase 1/2 numerical algorithms remain unchanged.
- [x] Validation runner requiring an actual CUDA device probe and the entire passing, zero-skip suite; report binds source/config/scripts, GPU/driver/runtime identity and validation XML.
- [x] CUDA benchmark harness with separate calibration, identical data/initialization, warmups, repeated fresh models, synchronized wall time, CUDA events, CUDA allocated/reserved peaks, throughput and per-epoch train/test observations.
- [x] Predeclared Lloyd-relative target, no time interpolation, explicitly censored misses, and separate monitored-state versus returned-finalizer availability.
- [x] Reproducible 128/256/1024-dimensional Gaussian workload configurations and pinned real GloVe-100 train/test prefixes.
- [x] Selected real embedding byte ranges and prepared arrays verified locally by SHA256. The entire 485 MB parent file is explicitly not claimed SHA256-verified.
- [x] Preparation-only mode emits zero GPU measurements; actual benchmark/summary paths reject missing/failed/mismatched validation and incomplete artifacts.
- [x] Immutable official CUDA image digest resolved, exact dependency overlay, bootstrap/validate-before-benchmark script, persistent failure/success exports, transfer package and [Runpod instructions](docs/RUNPOD.md).
- [x] Official Runpod Codex plugin 2.0.0 installed/enabled; 17 skill files and hosted MCP endpoint wiring verified.
- [ ] Restart/sign-in and authenticated Runpod Pod-list check: requires user UI action; no account connectivity claim yet.
- [ ] Container bootstrap and full CUDA correctness suite on real NVIDIA hardware.
- [ ] Actual GPU smoke run, followed by reviewed GPU research run and measured results log.

No GPU Pod has been provisioned by this work, and **zero GPU measurements exist**. The local host reports Torch 2.15.0 with no CUDA build/device. The proposed pinned Linux Torch 2.5.1/CUDA 12.4 image is prepared, not locally execution-validated. See EXPERIMENT_LOG.md for the local gate result and docs/RUNPOD.md for exact commands. Custom kernels, Triton optimization and distributed clustering have not been introduced.

After the hardware gate passes, inspect smoke results and only then execute the larger predeclared workloads. Scaling-law validation at paper-sized real embeddings and broader version/hardware CI remain later research work; these prepared development workloads do not reproduce the paper's largest scales.

### GPU execution request — access blocked, 11 November 2026

Inspected published checkout `c1b104b`. Preferred hardware: RTX 4090 24 GB; total task ceiling: below $10 including storage. No live Runpod tools are exposed, no CLI is installed, and no API-key environment variable is available. The installed plugin's endpoint configuration is not authenticated-access evidence. No active Pod, balance, stock, rate or NVIDIA execution has been verified; no paid infrastructure was provisioned.

Required next step is desktop restart/OAuth and a read-only Pod/account check. Paid provisioning still requires explicit approval after a concrete live-priced plan is available. The existing script must be paired with external budget/deadline control and verified Pod termination: its current EXIT trap exports artifacts only. GPU validation and benchmark milestones remain pending, with no new GPU results.

## Known limits

- Default dropped tails follow the paper's floor update count; retained tails are explicit and tested.
- Multiplicative zero-vector splits can remain coincident; no non-paper additive displacement is introduced.
- Only integer epoch budgets and Euclidean unweighted clustering are implemented.
- In-memory input/state, no resumable training, spherical clustering or ANN assignment.
- Process RSS includes interpreter/data/evaluation and is not isolated optimizer memory.
- PyTorch revival uses host-side seeded donor control; CUDA compatibility is implemented but unverified here. Device-native RNG is not silently substituted.
- Complete authors' slow-EMA routine is unavailable in the audited release; shadow split/half-life conventions are explicit interpretations.
- Small real-data CPU experiments and sample standard deviations are not confidence intervals or paper-scale embedding reproduction.
- No production release, CUDA benchmark, or paper table reproduction is claimed.

## 11 November 2026 — latest execution gate

Runpod CLI account authentication now verified; balance $10, current spend $0/hour, no Pods. This supersedes the previous access-blocked status. RTX 4090 is unavailable in the live catalog; A40 Secure Cloud is available at $0.59/hour GPU-only. Explicit paid provisioning approval is still absent. No NVIDIA validation/benchmark results exist. Storage-inclusive budget guard, artifact retrieval and verified termination remain prerequisites.
