# Runpod CUDA milestone: execution handoff

**Current state: prepared locally, not NVIDIA verified.** No Pod has been provisioned and no GPU benchmark has run. The local machine has macOS ARM64 and a CPU-only Torch 2.15.0 build. The proposed Linux CUDA image is a different, pinned environment and must pass the entire suite on actual hardware before any benchmark starts.

## Agent connection

The official [agent setup guide](https://agents.runpod.io/) was fetched and its Codex installation steps executed. `runpod@runpod` version 2.0.0 is installed/enabled, 17 nonempty skill files were verified, and `.mcp.json` registers `https://mcp.runpod.io/`. The authenticated MCP connection is **not verified** yet. Fully quit and reopen Codex Desktop, then complete the Runpod sign-in prompt. After sign-in, list Pods with the Runpod MCP tools to verify the account connection. An empty list still verifies connectivity. No API key was requested, printed or written by this setup.

The plugin is a control-plane integration; it does not provide CUDA to this local process. GPU experiments still need an actual provisioned NVIDIA host. Do not add a second `codex mcp add runpod` entry when the plugin already registers the server. No separate CLI/Flash SDK was installed during agent onboarding, following the guide.

## 1. Prepare a transfer package locally

From the existing repository:

```bash
.venv/bin/python scripts/fetch_gpu_embeddings.py
.venv/bin/python scripts/benchmark_cuda.py --config configs/gpu_smoke.json --output results/local/gpu_plan --prepare-only
.venv/bin/python runpod/package.py /tmp/e-means-gpu-source.tar.gz
```

If `data/glove100_subset.npz` already exists with its pinned arrays, it is included in the package; downloading it again is unnecessary. The source package contains code, configs, Runpod scripts, documentation, the small embedding subset, and the original Phase 1 regression fixtures needed by the complete test suite. It excludes virtual environments, user credentials and unrelated workspace files. Keep its `.sha256` sidecar. Output paths must be new.

`--prepare-only` loads/checks both real and synthetic inputs and emits `status: prepared`, `gpu_verified: false`, no measurements, and no GPU timings. The larger `configs/gpu_research.json` can be prepared the same way.

## 2. Provision a single NVIDIA Pod when ready

Use the Runpod plugin after sign-in, or the Runpod console, to select a **single Ampere/Hopper NVIDIA GPU** compatible with CUDA 12.4. A100/H100-class hardware permits FP32/FP64 validation; timings across different GPU types must not be pooled. The current image is not a promise of support for newer architectures. Use Linux AMD64, a persistent network volume mounted at `/workspace`, and enough host memory for the synthetic inputs and CPU test processes (16 GiB is a practical setup allowance, not a measured minimum).

Use this exact immutable container image from [runpod/image.json](../runpod/image.json):

```text
pytorch/pytorch@sha256:c8268a92a69bd500f8be0e665b2630ee006dadaf7bfbc24249141b15ff622755
```

The resolved official tag is `2.5.1-cuda12.4-cudnn9-runtime`. Configure the Pod start command as `sleep infinity` to keep the interactive container available. This image digest was resolved from the Docker registry locally; the image was **not built/run or GPU-validated locally**. The bootstrap script checks Linux x86_64, Python 3.11, Torch 2.5.1 and CUDA runtime 12.4 before installing the exact overlay in `runpod/requirements.lock`. Base transitive packages are frozen by the image digest; the overlay uses `--no-deps`, then `pip check`. The actual driver, package freeze and hardware identity are exported by the run.

Runpod's [storage documentation](https://docs.runpod.io/pods/storage/types) distinguishes network volumes, which persist independently, from Pod volume disks, which are lost when the Pod is deleted. Use an attached network volume for the `/workspace` results and download an additional export before deleting resources.

## 3. Transfer and bootstrap

Runpod documents the [web terminal](https://docs.runpod.io/pods/connect-to-a-pod) and [one-time file transfers](https://docs.runpod.io/pods/storage/transfer-files). On your local machine, using an already available `runpodctl` transfer client:

```bash
runpodctl send /tmp/e-means-gpu-source.tar.gz
```

In the Pod's web terminal, replace the transfer code with the one just printed:

```bash
cd /workspace
runpodctl receive YOUR_ONE_TIME_TRANSFER_CODE
tar -xzf e-means-gpu-source.tar.gz
cd /workspace/e-means
bash runpod/bootstrap.sh
```

If your client lacks `runpodctl`, use the platform's documented transfer installation or existing SSH/SCP access; agent onboarding intentionally did not install the CLI. The official base image itself does not configure SSH/Jupyter services, so do not assume those services exist merely from the image name. Compare `sha256sum /workspace/e-means-gpu-source.tar.gz` with the local package checksum before extraction. Authentication/transfer codes remain operator inputs, not values to commit to the repository.

## 4. Validate first, then benchmark automatically

For the initial protocol smoke run, launch detached from the web terminal:

```bash
mkdir -p /workspace/e-means-results
cd /workspace/e-means
nohup bash runpod/run.sh /workspace/e-means-results/gpu-smoke-001 configs/gpu_smoke.json > /workspace/e-means-results/gpu-smoke-001-launcher.log 2>&1 &
```

Observe progress:

```bash
tail -f /workspace/e-means-results/gpu-smoke-001/run.log
cat /workspace/e-means-results/gpu-smoke-001/validation/report.json
```

The script records the environment, fetches the pinned authors' oracle, runs the **complete suite**, and requires zero failures/errors/skips plus at least 20 actually executed new CUDA cases. It then validates/hashes the data, runs separate Lloyd target calibrations, identical-data warmups, repeated measurements and summaries. Missing NVIDIA hardware, dependency problems, a failed numerical assertion, skipped tests or a changed source/configuration leave the execution gate closed. Logs and failed results are retained/exported as failures. There is no unsafe `KMP_DUPLICATE_LIB_OK`, tolerance auto-relaxation, CPU fallback, Triton compilation or distributed mode.

The validation identity includes GPU properties/UUID/driver information, Torch/CUDA/cuDNN versions, device visibility and Python/platform. The benchmark must match it and the complete source/config/script fingerprint. The copied validation XML is checksummed. A different GPU, runtime, source or configuration requires revalidation.

Only after the smoke artifacts pass inspection, run the larger predeclared experiment in a **new directory**:

```bash
nohup bash runpod/run.sh /workspace/e-means-results/gpu-research-001 configs/gpu_research.json > /workspace/e-means-results/gpu-research-001-launcher.log 2>&1 &
```

The research config has three workloads, three seeds, two precisions, three methods and three measured repetitions: **162 future measured fits**, plus independent calibrations and warmups. The smoke config has 24 future fits. These are plans, not completed measurements. The deliberately unoptimized dimension-by-dimension assignment and frequent correctness checks can make GPU runs slow; no expected speedup or runtime is promised.

## 5. Metrics and interpretation

- Synchronized `resident_fit_wall_seconds` includes initialization, host-side RNG/revival, all epoch train/test evaluations and final test evaluation. Dataset generation/loading, process startup and H2D transfer are outside it. Initial H2D time is separately measured; do not call resident fit latency end-to-end service latency.
- `cuda_event_elapsed_seconds` brackets the same interval on the CUDA stream. It can include idle gaps while Python/host synchronization runs. It is **not pure kernel time**. Event timing follows [PyTorch CUDA timing guidance](https://docs.pytorch.org/docs/stable/notes/cuda.html).
- Warmup fits are not measurements. Each repeated contender starts a fresh model with identical device-resident train/test inputs and initial centroids. Order rotates deterministically. The allocator cache is kept; baseline allocated/reserved memory and absolute peaks are saved separately.
- Peak allocated/reserved CUDA bytes include resident inputs, model state, distance scratch and evaluation. Incremental allocated peak subtracts the pre-fit resident baseline. These are allocator measurements, not total `nvidia-smi` device use.
- Throughput counts actual training vectors visited (including Lloyd stopping and dropped-tail semantics) divided by resident fit or solver-loop time. Evaluation work is not added to the numerator; its overhead remains in the resident-fit denominator.
- MSE averages squared Euclidean norms per vector. Arithmetic follows each config dtype with FP64 loss reduction. FP32 and FP64 targets are calibrated and reported separately; no cross-precision pooling is performed.
- Each workload/seed/dtype has one separately saved Lloyd calibration. Its terminal train/test MSE multiplied by `1 + .001` defines the same target for all contenders. This rule is predeclared and not retuned after seeing e-means results. Calibration is excluded from timed contender fits.
- Time-to-target is the first **completed observed** evaluation at or below target. Epoch-zero main state, epoch main states, and final readout points are distinct. No interpolation or extrapolation is used. Misses are right-censored and never converted to zero or quietly dropped from unconditional averages.
- `train_time_to_target` / `test_time_to_target` monitor tagged main-or-final observations. Separate `returned_train_time_to_target` / `returned_test_time_to_target` use only the selected finalizer's returned result at completion. An early main-EMA hit must not be described as an early slow-EMA or closing-mean solution. Summaries preserve hit stages and both availability definitions. Shorter-budget finalizer comparisons require separately configured and validated runs, not retrospective finalization of these traces.
- Main-state histories precede finalization; closing/slow readout MSE is observed at completion. Summaries average repeated scalar measurements within seed, then calculate mean/sample SD across seeds. Reached-only target latency is explicitly conditional and accompanied by hit counts, not presented as an unconditional speedup.

## 6. Persistent exports

Normal completion and failures both write `execution_status.json` and create a checksummed archive on the mounted volume:

```text
/workspace/e-means-results/gpu-smoke-001.tar.gz
/workspace/e-means-results/gpu-smoke-001.tar.gz.sha256
```

Export another copy to your local machine using the same one-time transfer mechanism:

```bash
# Pod terminal
runpodctl send /workspace/e-means-results/gpu-smoke-001.tar.gz
# Local terminal, using the returned code
runpodctl receive YOUR_RESULT_TRANSFER_CODE
```

The archive includes validation XML/logs, pip freeze/check, NVIDIA metadata, config/source snapshots, target calibrations, per-repeat JSON/NPZ results, summaries and plots if benchmarking succeeded. Existing run/export paths are rejected. An abrupt host/power termination can prevent the EXIT export trap; atomic progress manifests and already-written files remain on the network volume. A missing final export or `status != complete` must never be treated as a completed measurement.

## Exact manual equivalents

If operating the steps independently after bootstrap, keep the source fixed and use:

```bash
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export CUDA_VISIBLE_DEVICES=0
export EMEANS_REFERENCE_DIR=/workspace/emeans-reference
python scripts/fetch_reference.py "$EMEANS_REFERENCE_DIR"
python scripts/validate_cuda.py --output /workspace/manual-validation-001
python scripts/benchmark_cuda.py --config configs/gpu_smoke.json --gate /workspace/manual-validation-001/report.json --output /workspace/manual-benchmark-001
MPLCONFIGDIR=/workspace/mpl-cache python scripts/summarize_cuda.py /workspace/manual-benchmark-001 --plots
```

Stop immediately if validation fails. Do not hand-edit its report to open the gate. Actual NVIDIA results must be reviewed and added to EXPERIMENT_LOG.md only after this execution succeeds.
